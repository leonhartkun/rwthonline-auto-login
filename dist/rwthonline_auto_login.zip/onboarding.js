import { generate_totp, parse_otpauth_uri } from "./totp.mjs";

const form = document.getElementById("onboarding_form");
const username_input = document.getElementById("username");
const password_input = document.getElementById("password");
const token_label_input = document.getElementById("token_label");
const token_qr_input = document.getElementById("token_qr");
const token_preview = document.getElementById("token_preview");
const verification_code = document.getElementById("verification_code");
const verification_countdown = document.getElementById("verification_countdown");
const status_element = document.getElementById("status");
const helper_setup = document.getElementById("helper_setup");
const release_base_url = "https://github.com/leonhartkun/rwthonline-auto-login/releases/latest/download";
const repository_url = "https://github.com/leonhartkun/rwthonline-auto-login";
let helper_installed = false;
let preview_totp_configuration;

function set_status(message, type = "") {
  status_element.textContent = message;
  status_element.className = type;
}

function setup_install_command() {
  const extension_id = chrome.runtime.id;
  const is_windows = navigator.platform.toLowerCase().includes("win");
  const command = is_windows
    ? `irm ${release_base_url}/install_windows.ps1 | iex; Install-RwthonlineHelper -ExtensionId ${extension_id}`
    : `curl -fsSL ${release_base_url}/install_macos.sh | sh -s -- ${extension_id}`;
  document.getElementById("install_command").textContent = command;
  document.getElementById("source_link").href = repository_url;
  document.getElementById("copy_install_command").addEventListener("click", async () => {
    await navigator.clipboard.writeText(command);
    set_status("安装命令已复制。安装完成后，本页会自动继续。", "success");
  });
}

async function decode_local_qr(file) {
  if (!("BarcodeDetector" in window)) {
    throw new Error("当前 Chrome 不支持本地二维码解析。请升级 Chrome 后重试。");
  }
  const supported_formats = await BarcodeDetector.getSupportedFormats();
  if (!supported_formats.includes("qr_code")) {
    throw new Error("当前 Chrome 不支持二维码解析。请升级 Chrome 后重试。");
  }

  const detector = new BarcodeDetector({ formats: ["qr_code"] });
  const image = await createImageBitmap(file);
  try {
    const results = await detector.detect(image);
    if (results.length === 0) {
      throw new Error("未在图片中识别到二维码。请使用清晰的 Token 二维码截图。");
    }
    return results[0].rawValue;
  } finally {
    image.close();
  }
}

async function refresh_verification_code() {
  if (!preview_totp_configuration) return;
  const { secret, algorithm, digits, period } = preview_totp_configuration;
  verification_code.textContent = await generate_totp(secret, Date.now(), { algorithm, digits, period });
  const seconds_remaining = period - (Math.floor(Date.now() / 1_000) % period);
  verification_countdown.textContent = `${seconds_remaining} 秒后更新`;
}

token_qr_input.addEventListener("change", async () => {
  token_preview.hidden = true;
  preview_totp_configuration = undefined;
  const selected_file = token_qr_input.files[0];
  if (!selected_file) return;

  try {
    preview_totp_configuration = parse_otpauth_uri(await decode_local_qr(selected_file));
    await refresh_verification_code();
    token_preview.hidden = false;
  } catch (error) {
    set_status(error.message, "error");
  }
});

function send_background(message) {
  return new Promise((resolve) => chrome.runtime.sendMessage(message, resolve));
}

async function check_helper_status() {
  const status = await send_background({ action: "get_helper_status" });
  if (!status?.ok) {
    return;
  }
  if (!helper_installed) {
    helper_installed = true;
    helper_setup.hidden = true;
    set_status("已检测到本机助手。填写账号、密码并选择 Token 二维码后即可保存。", "success");
  }
  window.clearInterval(helper_status_timer);
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  set_status("正在本地读取二维码…");

  try {
    const selected_file = token_qr_input.files[0];
    if (!helper_installed) {
      throw new Error("请先完成本机助手安装。");
    }
    if (!selected_file || !password_input.value) {
      throw new Error("请填写密码并选择 Token 二维码图片。");
    }
    const totp_configuration = parse_otpauth_uri(await decode_local_qr(selected_file));
    const response = await send_background({
      action: "configure_credentials",
      username: username_input.value,
      password: password_input.value,
      totp_secret: totp_configuration.secret,
      totp_algorithm: totp_configuration.algorithm,
      totp_digits: totp_configuration.digits,
      totp_period: totp_configuration.period,
      token_label: token_label_input.value.trim(),
    });
    if (!response?.ok) {
      throw new Error(response?.error || "无法保存到系统保险库。");
    }
    await chrome.storage.local.set({ token_label: token_label_input.value.trim() });
    password_input.value = "";
    token_qr_input.value = "";
    set_status("已保存。正在关闭设置页…", "success");
    setTimeout(() => send_background({ action: "close_onboarding" }), 600);
  } catch (error) {
    set_status(error.message, "error");
  }
});

setup_install_command();
check_helper_status().catch(() => {});
const helper_status_timer = window.setInterval(check_helper_status, 1500);
window.setInterval(() => refresh_verification_code().catch(() => {}), 1000);
